#include <stdlib.h>
#include <stdio.h>

#include "MAZE.h"

MAZE::MAZE() {
    mass = NULL;
    h = w = 0;
}

MAZE::~MAZE() {
    if(mass) {
        for(int i = 0; i < h; i++)
            if(mass[i]) free(mass[i]);
        free(mass);
    }
}

bool MAZE::create(char *way){
    FILE *file;
    if((file = fopen(way, "rb")) == NULL)
        return 0;

    unsigned char i, j;

    fread(&h, 1, 1, file);
    fread(&w, 1, 1, file);
    fread(&count, 1, 4, file);

    mass = (char**)malloc(h * sizeof(char*));
    for(i = 0; i < h; i++)
        mass[i] = (char*)calloc(w, sizeof(char));

    for(i = 0; i < h; i++)
        for(j = 0; j < w; j++)
            fread(&mass[i][j], 1, 1, file);

    for(i = 0; i < 5; i++)
        fread(&pos[i], 1, 16, file);

    return 1;
}

char MAZE::check_value(unsigned char i, unsigned char j){
    return mass[i][j];
}

void MAZE::change_value(unsigned char i, unsigned char j, char value){
    mass[i][j] = value;
}

DOT MAZE::get_size(){
    DOT size;
    size.x = h;
    size.y = w;
    return size;
}

char MAZE::count_napr(DOT point){
    char count = 0;
    for(char i = 0; i < 4; i++)
        if(!check_wall(point, i))
            count++;
    return count;
}

bool MAZE::check_wall(DOT point, char dir){
    int i, j;
    i = point.x / 25;
    j = point.y / 25;

    switch(dir){
        case 0: if(mass[j-1][i] != 0) return 0; break;
        case 1: if(mass[j][i+1] != 0) return 0; break;
        case 2: if(mass[j+1][i] != 0) return 0; break;
        case 3: if(mass[j][i-1] != 0) return 0; break;
    }
    return 1;
}

unsigned int MAZE::get_count(){
    return count;
}

void MAZE::gen_berry(){
    char i, j, temp;
    while((temp = mass[i = rand() % h][j = rand() % w]) != 3);
    mass[i][j] = 4;
}

DOT MAZE::get_pos(char i){
    return pos[i];
}
