#include "ENEMY.h"

ENEMY::ENEMY() {
    type = 1;
}

void ENEMY::set_type(bool value){
    type = value;
}

bool ENEMY::get_type(){
    return type;
}
