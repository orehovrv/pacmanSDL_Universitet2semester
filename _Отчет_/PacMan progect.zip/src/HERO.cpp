#include <stdlib.h>
#include <stdio.h>

#include "HERO.h"

HERO::HERO() {
    score = 0;
    mouth = 0;
    count_money = 0;
    boost = 0;
}

char HERO::get_mouth(){
    return mouth;
}

void HERO::set_mouth(char value){
    mouth = value;
}

void HERO::incMon(){
    count_money++;
}

unsigned int HERO::get_count(){
    return count_money;
}

unsigned int HERO::get_boost(){
    return boost;
}

void HERO::set_boost(unsigned int value){
    boost = value;
}

unsigned int HERO::get_score(){
    return score;
}

void HERO::set_score(unsigned int value){
    score = value;
}
