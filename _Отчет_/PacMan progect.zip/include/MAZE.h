#ifndef MAZE_H
#define MAZE_H

#include "DOT.h"

#define scale 25

class MAZE {
    private:
        char **mass = 0;
        unsigned char h, w;
        unsigned int count;

        DOT pos[5];

    public:
        MAZE();
        ~MAZE();
        bool create(char*);
        DOT  get_size();

        bool check_wall(DOT, char);
        char check_value(unsigned char, unsigned char);
        void change_value(unsigned char, unsigned char, char);
        char count_napr(DOT);
        unsigned int get_count();
        void gen_berry();
        DOT  get_pos(char);
};

#endif // MAZE_H
