#ifndef DOT_H_INCLUDED
#define DOT_H_INCLUDED

typedef struct _DOT{
    double y, x;
} DOT;

#endif // DOT_H_INCLUDED
