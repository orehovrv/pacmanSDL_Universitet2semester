#ifndef ENEMY_H
#define ENEMY_H

#include "ENTITY.h"

class ENEMY : public ENTITY{
    private:
        bool type;

    public:
        ENEMY();
        bool get_type();
        void set_type(bool);
};

#endif // ENEMY_H
