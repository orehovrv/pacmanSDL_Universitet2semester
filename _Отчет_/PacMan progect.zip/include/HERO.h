#ifndef HERO_H
#define HERO_H

#include "ENTITY.h"

class HERO : public ENTITY {
    private:
        unsigned int score, count_money, boost;
        char mouth;

    public:
        HERO();
        char get_mouth();
        void set_mouth(char);
        unsigned int get_count();
        unsigned int get_score();
        void set_score(unsigned int);
        void incMon();
        unsigned int get_boost();
        void set_boost(unsigned int);
};

#endif // HERO_H
