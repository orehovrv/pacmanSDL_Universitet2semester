#ifndef LOGICS_H
#define LOGICS_H

#include <time.h>

#include "MAZE.h"
#include "HERO.h"
#include "ENEMY.h"

class LOGICS {
    public:
        MAZE maze;
        HERO pacman;
        ENEMY enemy[4];
        char regim; //regim = 1 - game, regim = 0 - pacman die
        unsigned int frame;

        bool gen (char*);
        void step();
        void eat();
        void die_pacman();
};

#endif // LOGICS_H
