#ifndef ENTITY_H
#define ENTITY_H

#include "DOT.h"
#include "MAZE.h"

class ENTITY {
    private:
        DOT point;
        char dir;
        double speed;

    public:
        ENTITY();
        char get_dir();
        void set_dir(char);
        void new_dir(DOT, MAZE&);
        DOT  get_point();
        void set_point(DOT);
        void rand_pos(MAZE&);
        double get_speed();
        void   set_speed(double);
        void motion(MAZE&);
        bool center();
};

#endif // ENTITY_H
